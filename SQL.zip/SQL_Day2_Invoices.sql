Create Database db_Invoices

use db_Invoices

Create Table  tbl_Customers
(
CustomerEmailID varchar(100) primary key,
CustomerName varchar(100) not null,
CustomerCity varchar(100) not null,
CustomerContactNo varchar(15) not null unique,
CustomerAddress varchar(max) not null
)

insert tbl_Customers values('abc@gmail.com','Mounika','BGL','9948498834','JP NAGAR ,3rd Phase')
insert tbl_Customers values('cde@gmail.com','Bhagya','BGL','9948497734','Gandhinagar')
insert tbl_Customers values('efg@gmail.com','Surekha','Chennai','9948495534','MG Road')
insert tbl_Customers values('ghi@gmail.com','Anil','Pune','9948496634','Koramangala')
insert tbl_Customers values('ijk@gmail.com','Sai','Chennai','9948493334','Basavannagudi')

Select * from tbl_Customers


Create Table tbl_Items
(
ItemID int identity(1,1) primary key,
ItemName varchar(100) not null,
ItemPrice int not null check (ItemPrice > 0)
)

insert tbl_Items values('Samsung',20000)
insert tbl_Items values('BSNL',25000)
insert tbl_Items values('IPhone',30000)
insert tbl_Items values('Vivo',30000)
insert tbl_Items values('Coolpad',25000)
insert tbl_Items values('Oppo',40000)
insert tbl_Items values('Airtel',35000)
insert tbl_Items values('Idea',45000)
insert tbl_Items values('Motorola',50000)
insert tbl_Items values('Honor',40000)

Select * from tbl_Items


Create Table tbl_Invoices
(
InvoiceID int identity(1000,1) primary key,
CustomerEmailID varchar(100) not null
foreign key references tbl_Customers(CustomerEmailID),
InvoiceCity varchar(100) not null,
InvoiceDate datetime not null
)

insert tbl_Invoices values('abc@gmail.com','BGL',getdate())
insert tbl_Invoices values('efg@gmail.com','Chennai',getdate())
insert tbl_Invoices values('ijk@gmail.com','Pune',getdate())
insert tbl_Invoices values('cde@gmail.com','BGL',getdate())
insert tbl_Invoices values('ghi@gmail.com','Chennai',getdate())


Select * from tbl_Invoices


Create Table tbl_InvoiceItems
(
InvoiceID int foreign key references tbl_Invoices(InvoiceID),
ItemID int foreign key references tbl_Items(ItemID),
ItemQty int not null check (ItemQty > 0),
ItemPrice int not null check (Itemprice > 0),
primary key (InvoiceID , ItemID)
)

insert tbl_InvoiceItems values(1002,3,2,100)
insert tbl_InvoiceItems values(1002,4,3,100)
insert tbl_InvoiceItems values(1000,5,2,200)
insert tbl_InvoiceItems values(1001,2,1,250)
insert tbl_InvoiceItems values(1005,1,5,500)
insert tbl_InvoiceItems values(1007,6,3,450)
insert tbl_InvoiceItems values(1005,4,4,150)
insert tbl_InvoiceItems values(1007,7,2,230)
insert tbl_InvoiceItems values(1000,1,5,300)
insert tbl_InvoiceItems values(1001,8,3,280)

Select * from tbl_InvoiceItems

Select distinct CustomerEmailID from tbl_Invoices

--SUB QUERY

--in

Select * from tbl_Customers where CustomerEmailID in(Select distinct CustomerEmailID from tbl_Invoices)

Select * from tbl_Customers where CustomerEmailID not in(Select distinct CustomerEmailID from tbl_Invoices)

Select * from tbl_Items where ItemID not in(Select distinct ItemID from tbl_InvoiceItems)

Select * from tbl_Items where ItemID = (Select top 1 ItemID from tbl_InvoiceItems group by ItemID
order by sum(ItemQty) desc)

Select * from tbl_Items where ItemID in (Select top 1 with ties ItemID from tbl_InvoiceItems group by ItemID
order by sum(ItemQty) desc)

--JOINS

Select tbl_Invoices.InvoiceID , tbl_Invoices.InvoiceCity , tbl_Invoices.InvoiceDate ,
tbl_Invoices.CustomerEmailID , tbl_Customers.CustomerName 
from tbl_Invoices join tbl_Customers
on
tbl_Invoices.CustomerEmailID=tbl_Customers.CustomerEmailID


Select tbl_Invoices.InvoiceID,tbl_Invoices.InvoiceCity,tbl_Invoices.InvoiceDate,
tbl_InvoiceItems.ItemID,tbl_InvoiceItems.ItemQty,tbl_InvoiceItems.ItemPrice
from tbl_Invoices join tbl_InvoiceItems
on
tbl_Invoices.InvoiceID=tbl_InvoiceItems.InvoiceID


Select tbl_Invoices.InvoiceID,tbl_Invoices.CustomerEmailID,tbl_Invoices.InvoiceCity,tbl_Invoices.InvoiceDate,
tbl_InvoiceItems.ItemID,tbl_InvoiceItems.ItemQty,tbl_InvoiceItems.ItemPrice,tbl_Items.ItemName
from tbl_Invoices join tbl_InvoiceItems
on
tbl_Invoices.InvoiceID=tbl_InvoiceItems.InvoiceID
join tbl_Items
on
tbl_Items.ItemID=tbl_InvoiceItems.ItemID
join tbl_Customers
on
tbl_Customers.CustomerEmailID=tbl_Invoices.CustomerEmailID


--INNER JOIN

Select tbl_Customers.CustomerEmailID,tbl_Customers.CustomerName,
tbl_Invoices.InvoiceID,tbl_Invoices.InvoiceCity from tbl_Customers
join tbl_Invoices
on
tbl_Customers.CustomerEmailID=tbl_Invoices.CustomerEmailID

--LEFT OUTER JOIN

Select tbl_Customers.CustomerEmailID,tbl_Customers.CustomerName,
tbl_Invoices.InvoiceID,tbl_Invoices.InvoiceCity from tbl_Customers
left outer join tbl_Invoices
on
tbl_Customers.CustomerEmailID=tbl_Invoices.CustomerEmailID

--RIGHT OUTER JOIN

Select tbl_Customers.CustomerEmailID,tbl_Customers.CustomerName,
tbl_Invoices.InvoiceID,tbl_Invoices.InvoiceCity from tbl_Customers
right outer join tbl_Invoices
on
tbl_Customers.CustomerEmailID=tbl_Invoices.CustomerEmailID

--FULL OUTER JOIN

Select tbl_Customers.CustomerEmailID,tbl_Customers.CustomerName,
tbl_Invoices.InvoiceID,tbl_Invoices.InvoiceCity from tbl_Customers
full outer join tbl_Invoices
on
tbl_Customers.CustomerEmailID=tbl_Invoices.CustomerEmailID

--CROSS JOIN

Select * from tbl_Customers cross join tbl_Invoices



























