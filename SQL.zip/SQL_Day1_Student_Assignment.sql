--Create a Database named "Students_DB"

Create Database Student_DB

use Student_DB

--Create a Table named "tbl_Students"
Create Table tbl_Students
(
StudentID int,
StudentName varchar(100),
StudentCity varchar(100),
StudentDept varchar(100),
StudentDOB datetime,
StudentDOJ datetime,
StudentStatus varchar(100),
Marks_10th int,
Marks_12th int
)

--Insert some records in the tbl_Students table(min 10 rows)

insert tbl_Students values(1001,'Mounika','AP','CSE','11/30/1996','12/12/2017','Completed',550,980)
insert tbl_Students values(1002,'Bhagya','BGL','CSE','06/14/1995','10/10/2015','Studying',60,70)
insert tbl_Students values(1003,'Anil','BGL','ECE','09/28/1996','12/06/2015','Completed',55,80)
insert tbl_Students values(1004,'Sainath','HYD','EEE','07/09/1994','01/23/2016','Completed',95,85)
insert tbl_Students values(1005,'Surekha','Pune','CSE','06/23/1993','01/15/2013','Studying',70,75)
insert tbl_Students values(1006,'Sathya','Chennai','ECE','05/15/1995','05/07/2012','Completed',65,40)
insert tbl_Students values(1007,'Sampath','BGL','EEE','12/07/1997','04/26/2011','Studying',20,30)
insert tbl_Students values(1008,'Sathish','Chennai','CSE','01/13/1994','11/11/2014','Completed',35,45)
insert tbl_Students values(1009,'Sai','Mumbai','MECH','02/24/1995','10/05/2018','Studying',55,55)
insert tbl_Students values(1010,'Sree','HYD','MECH','03/22/1994','09/12/2018','Studying',75,65)

Select * from tbl_Students

--Reports
--------

--Create a List of students from 'BGL' City

Select * from tbl_Students where StudentCity='BGL'

--Create a List of students whose 12th Marks is between 60 and 75

Select * from tbl_Students where Marks_12th between 60 and 75

--Create a List of students (StudentID , StudentName , StudentDOB, STudentStatus)

Select StudentID,StudentName,StudentDOB,StudentStatus from tbl_Students

--Create a List of students in the descending order based on the 12th marks and if the marks is same then sort again as per the 10th marks descending order

Select * from tbl_Students order by Marks_12th desc , Marks_10th desc

--Retrieve the total numbers of students

Select count(*) from tbl_Students

--Create a List of students who joined in January Month/Current Month

Select * from tbl_Students where datename(mm,StudentDOJ) in('January','December')

--Create a List of students who joined 2 years ago

Select * from tbl_Students where datediff(yy,StudentDOJ,getdate()) < 2


--Create a List of students department names with no of students

Select StudentDept,count(*) from tbl_Students group by StudentDept

--Create a List of student cities with count of students

Select StudentCity,count(*) from tbl_Students group by StudentCity

--Update some students city from Chennai to Pune

update tbl_Students set StudentCity='Pune' where StudentID=1006

Select * from tbl_Students

--Create a List of students department with avg of 12th mark where avg of 12th mark is more than 50

Select StudentDept ,avg(Marks_12th) from tbl_Students 
group by StudentDept having avg(Marks_12th)>50

--Create a Table tbl_Courses (StudentID , CourseName , Duration ) - Add Some records

Create Table tbl_Courses
(
StudentID int,
CourseName varchar(100),
Duration int
)

insert tbl_Courses values(1001,'DOTNET',2)
insert tbl_Courses values(1002,'JAVA',3)
insert tbl_Courses values(1001,'BIGDATA',2)
insert tbl_Courses values(1003,'PHYTHON',3)
insert tbl_Courses values(1002,'ADVANCE JAVA',4)

Select * from tbl_Courses

--Create a List of Students (StudentID , NoOfCourses)

Select StudentID,count(*) as NoOfCourses from tbl_Courses group by StudentID

--Change the status of some students from Trainee to completed

update tbl_Students set StudentStatus='Completed' where StudentID=1002

Select * from tbl_Students

--Create a List of Students who have joined in the current month

Select * from tbl_Students where datename(mm,StudentDOJ)=datename(mm,getdate())















