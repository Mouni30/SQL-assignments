--OnlineFoodOrderingDB

Create Database OnlineFoodOrdering_DB

use OnlineFoodOrdering_DB

--Tables
-----------

--Create a Table called Restaurants
--RestaurantID(PK,Auto), RestaurantName , RestaurantAddress , RestaurantCity , ContactNo

Create Table tbl_Restaurants
(
RestaurantID int identity(1000,1) primary key,
RestaurantName varchar(100) not null,
RestaurantAddress varchar(max) not null,
RestaurantCity varchar(100) not null,
ContactNo varchar(15) not null unique
)

--Insert Records

insert tbl_Restaurants values('CheckPost','JP Nagar','BGL','9948498834')
insert tbl_Restaurants values('Nandhana','BTM','Chennai','9948497734')
insert tbl_Restaurants values('Meghana','Koramangala','Pune','9948495534')
insert tbl_Restaurants values('Empire','MG Road','Chennai','9948494434')
insert tbl_Restaurants values('Paradise','Basavannagudi','BGL','9948492234')

Select * from tbl_Restaurants

--Create a Table called RMenuItems
--MenuID (PK , Auto) ,RestID (FK), MenuName , MenuType , MenuCategory , MenuPrice , MenuDesc

Create Table RMenuItems
(
MenuID int identity(100,1) primary key,
RestaurantID int foreign key references tbl_Restaurants(RestaurantID),
MenuName varchar(100) not null,
MenuType varchar(100) not null,
MenuCategory varchar(100) not null,
MenuPrice int not null,
MenuDesc varchar(100) not null
)

--Insert Records
insert RMenuItems values(1000,'Fried Rice','Veg','South Indian',130,'Rice,Ghee,Vegetables')
insert RMenuItems values(1000,'Chicken Biriyani','Non-Veg','North Indian',150,'Rice,Ghee,Chicken')
insert RMenuItems values(1004,'Egg Noodles','Non-Veg','Chinese',130,'Egg,Oil,Noodles')
insert RMenuItems values(1005,'Veg Biriyani','Veg','North Indian',130,'Rice,Ghee,Vegetables')
insert RMenuItems values(1004,'Egg Fried Rice','Non-Veg','South Indian',130,'Rice,Ghee,Egg')

Select * from RMenuItems


--Create a Table called Customers
--CustomerID (PK, Email) , CustomerName , CustomerCity , CustomerDOB , CustomerGender , CustomerPassword

Create Table tbl_Customers
(
CustomerEmailID varchar(100) primary key,
CustomerName varchar(100) not null,
CustomerCity varchar(100) not null,
CustomerDOB datetime not null,
CustomerGender varchar(100) not null,
CustomerPassword varchar(100) not null
)

--Insert Records

insert tbl_Customers values('mouni@gmail.com','Mounika','BGL','11/30/1996','F','pass@123')
insert tbl_Customers values('bhagya@gmail.com','Bhagya','Chennai','06/14/1995','F','pass@345')
insert tbl_Customers values('anil@gmail.com','Anil','BGL','09/28/1996','M','pass@567')
insert tbl_Customers values('surekha@gmail.com','Surekha','Pune','01/10/1995','F','pass@789')
insert tbl_Customers values('sai@gmail.com','Sainath','Chennai','05/23/1996','M','pass@912')

Select * from tbl_Customers

-- Create a table called Orders
--OrderID (PK, Auto) , CustomerID (FK) , OrderDate , DeliveryAddress , OrderStatus

Create Table tbl_Orders
(
OrderID int identity(1,1) primary key,
CustomerEmailID varchar(100) not null 
foreign key references tbl_Customers(CustomerEmailID),
OrderDate datetime not null,
DeliveryAddress varchar(max) not null,
OrderStatus varchar(100) not null
)

--Insert Records

insert tbl_Orders values('anil@gmail.com',getdate(),'JP Nagar','Prepare')
insert tbl_Orders values('bhagya@gmail.com',getdate(),'BTM','Dispatch')
insert tbl_Orders values('anil@gmail.com',getdate(),'MG Road','Delivered')
insert tbl_Orders values('mouni@gmail.com',getdate(),'JP Nagar','Prepare')
insert tbl_Orders values('sai@gmail.com',getdate(),'BTM','Dispatch')

Select * from tbl_Orders



--Create a table called OrderMenus
--OrderID (FK) , MenuID(FK) , MenuQty , MenuPrice 
--Note : OrderID & MenuID should be together primary key

Create Table tbl_OrderMenus
(
OrderID int foreign key references tbl_Orders(OrderID),
MenuID int foreign key references RMenuItems(MenuID),
MenuQty int not null,
MenuPrice int not null,
primary key (OrderID,MenuID)
)

--Insert Records

insert tbl_OrderMenus values(1,100,2,250)
insert tbl_OrderMenus values(2,102,3,150)
insert tbl_OrderMenus values(1,101,1,350)
insert tbl_OrderMenus values(3,103,2,200)
insert tbl_OrderMenus values(2,104,3,250)

Select * from tbl_OrderMenus

--Reports / Queries

--Show the list of Restaurant of specific city

Select * from tbl_Restaurants where RestaurantCity='BGL'

--Show the list of all Restaurants along with menus (RestaurantID , RestaurantName ,
--MenuID , MenuName , MenuPrice)

Select tbl_Restaurants.RestaurantID,tbl_Restaurants.RestaurantName,RMenuItems.MenuID,
RMenuItems.MenuName,RMenuItems.MenuPrice
from tbl_Restaurants
join RMenuItems
on
tbl_Restaurants.RestaurantID=RMenuItems.RestaurantID

--Show the list of  Restaurants along with menus (RestaurantID , RestaurantName ,MenuID , MenuName ,
--MenuPrice) of specific city

Select tbl_Restaurants.RestaurantID,tbl_Restaurants.RestaurantName,RMenuItems.MenuID,
RMenuItems.MenuName,RMenuItems.MenuPrice
from tbl_Restaurants
join RMenuItems
on
tbl_Restaurants.RestaurantID=RMenuItems.RestaurantID
where RestaurantCity='BGL'

--Show the list of Orders of a specific customer (based on customerid)

Select * from tbl_Orders where CustomerEmailID='anil@gmail.com'

--Show the list of orders along with ordermenus (OrderID , CustomerID , OrderDate , MenuID , MenuQty , 
--MenuPrice)

Select tbl_Orders.OrderID,tbl_Orders.CustomerEmailID,tbl_Orders.OrderDate,tbl_OrderMenus.MenuID,
tbl_OrderMenus.MenuQty,tbl_OrderMenus.MenuPrice
from tbl_Orders
join tbl_OrderMenus
on
tbl_Orders.OrderID=tbl_OrderMenus.OrderID

--Show the list of latest 5 orders of a specific customer (based on CustomerID)

Select * from tbl_Orders order by CustomerEmailID desc 

--Show the list of menus in price ascending order
Select * from RMenuItems order by MenuPrice asc

--Show the list of cities along with number of restaurants

Select RestaurantCity,count(*) from tbl_Restaurants group by RestaurantCity

--Show the list of customers who never placed any order

Select * from tbl_Customers where CustomerEmailID not in(Select distinct CustomerEmailID from tbl_Orders)

-- Show the menuitem details which has highest menuprice(First)

Select top 1 * from RMenuItems order by MenuPrice desc

--Show the menuitem details which has second highest menuprice(Second)
 
Select top 2 * from RMenuItems order by MenuPrice desc









































































