--Create a Database named "Emp_DB"

Create Database Emp_DB

use Emp_DB

--Create a Table named "Employees"

Create Table tbl_Employees
(
EmployeeID int,
EmployeeFName varchar(100),
EmployeeLName varchar(100),
EmployeeCity varchar(100),
EmployeeDOB datetime,
EmployeeSalary int,
EmployeeStatus varchar(100)
)

--Add  columns named EmployeeDept & EmployeeDOJ in the tbl_Employees table

alter table tbl_Employees add EmployeeDept varchar(100)

alter table tbl_Employees add EmployeeDOJ datetime

Select * from tbl_Employees

--Insert some records in the Employees table(min 10 rows)

insert tbl_Employees values(1001,'Bhagya','Sree','BGL','06/14/1995',30000,'Working','HR','12/12/2017')
insert tbl_Employees values(1002,'Hima','Mounika','AP','11/30/1996',40000,'Working','Manager','02/03/2016')
insert tbl_Employees values(1003,'Anil','Sai','BGL','09/28/1956',45000,'Resigned','CEO','09/28/2016')
insert tbl_Employees values(1004,'Sai','Nath','HYD','04/14/1995',30000,'Working','HR','06/26/2015')
insert tbl_Employees values(1005,'Sree','Surekha','Pune','03/23/1994',20000,'Resigned','Ass.Manager','12/12/2015')
insert tbl_Employees values(1006,'Sathya','Sai','HYD','01/01/1993',40000,'Working','HR','12/12/2016')
insert tbl_Employees values(1007,'Jai','Surya','Chennai','02/03/1993',50000,'Resigned','CEO','12/12/2014')
insert tbl_Employees values(1008,'Sai','Sampath','Chennai','04/28/1997',20000,'Working','Manager','03/12/2018')
insert tbl_Employees values(1009,'Surya','Sathish','BGL','03/17/1994',40000,'Resigned','HR','04/09/2015')
insert tbl_Employees values(1010,'Avi','Nash','Pune','03/23/1998',30000,'Working','Manager','06/23/2017')

Select * from tbl_Employees

--Reports
--------

--Create a List of employees from 'Chennai' City

Select * from tbl_Employees where EmployeeCity='Chennai'

--Create a List of employees whose salary is between 25000 and 50000

Select * from tbl_Employees where EmployeeSalary between 20000 and 50000

--Create a List of employees (EmployeeFullName , EmployeeID , EmployeeCity)

Select EmployeeFName+EmployeeLName as EmployeeFullName,EmployeeID , EmployeeCity from tbl_Employees

--Create a List of Employees in the ascending order based on the length of their first name

Select * from tbl_Employees order by len(EmployeeFName) desc

--Retrieve the sum of salary

Select sum(EmployeeSalary) from tbl_Employees

--Retrieve the total number of employees

Select count(*) from tbl_Employees

--Create a List of employees who joined in January Month/Current Month

Select * from tbl_Employees where datename(mm,EmployeeDOJ) in('January','December') 

--Create a List of employees whose experience is more than 5 years

Select * from tbl_Employees where datediff(yy,EmployeeDOJ,getdate()) > 5 

--Create a List of employee department names with no of employees

Select EmployeeDept,count(*) from tbl_Employees group by EmployeeDept

--Create a List of employee cities with count of employees

Select EmployeeCity,count(*) from tbl_Employees group by EmployeeCity

--Update some employees city from Chennai to Pune

update tbl_Employees set EmployeeCity='Pune' where EmployeeID=1007

Select * from tbl_Employees

--Create a List of employee department with sum of salary where sum of salary is more than 50000

Select EmployeeDept ,sum(EmployeeSalary) from tbl_Employees 
group by EmployeeDept having sum(EmployeeSalary)>50000

--Create a Table EmployeesProjects (EmployeeID , ProjectName , Duration , SkillSet) - Add Some records

Create Table tbl_EmployeeProjects
(
EmployeeID int,
ProjectName varchar(100),
Duration int,
Skillset varchar(100)
)

insert tbl_EmployeeProjects values(1001,'Talking Plant',2,'IOT')
insert tbl_EmployeeProjects values(1002,'HyperSpectral Images',3,'MATLAB')
insert tbl_EmployeeProjects values(1001,'Chart Boat',2,'JAVA')
insert tbl_EmployeeProjects values(1003,'Game Application',3,'JAVA')
insert tbl_EmployeeProjects values(1002,'Voice Testing',4,'IOT')

Select * from tbl_EmployeeProjects

--Create a List of Employees (EmployeeID , NoOfProjects)

Select EmployeeID,count(*) as NoOfProjects from tbl_EmployeeProjects group by EmployeeID

--Change the status of some employee from working to resigned

update tbl_Employees set EmployeeStatus='Resigned' where EmployeeID=1006 

Select * from tbl_Employees

--Create a List of Employees who have joined in the current month

Select * from tbl_Employees where datename(mm,EmployeeDOJ)=datename(mm,getdate())




