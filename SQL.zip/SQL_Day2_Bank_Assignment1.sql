--Create a Database named BankDB

Create Database Bank_DB

use Bank_DB

--Tables
-----

--CustomersInfo with Auto gen CustomerID
--(CustomerID(PK) , CustomerName, CustomerCity, CustomerAddress , CustomerMobileNo(U), PAN (U), 
--CustomerPassword , CustomerEmailID (U) )

Create Table tbl_CustomerInfo
(
CustomerID int identity(1000,1) primary key,
CustomerName varchar(100) not null,
CustomerCity varchar(100) not null,
CustomerAddress varchar(max) not null,
CustomerMobileNo varchar(15) not null unique,
Pan varchar(15) not null unique,
CustomerPassword varchar(100) not null,
CustomerEmailId varchar(100) not null unique
)

--Insert Records

insert tbl_CustomerInfo values('Mounika','BGL','JP NAGAR','9948498834','EPAN123','pass@123','mouni@gmail.com')
insert tbl_CustomerInfo values('Bhagya','BGL','Gandhinagar','9948499934','EPAN124','pass@124','bhagya@gmail.com')
insert tbl_CustomerInfo values('Anil','Chennai','JP NAGAR','9948491134','EPAN125','pass@125','anil@gmail.com')
insert tbl_CustomerInfo values('Sainath','Pune','Koramangala','9948492234','EPAN126','pass@126','sai@gmail.com')
insert tbl_CustomerInfo values('Surekha','Mumbai','MG Road','9948494434','EPAN127','pass@127','surekha@gmail.com')
insert tbl_CustomerInfo values('Sathya','Pune','Basavannagudi','9948495534','EPAN128','pass@128','sathya@gmail.com')
insert tbl_CustomerInfo values('Sampath','Chennai','Bull Temple','9948496634','EPAN129','pass@129','sampath@gmail.com')
insert tbl_CustomerInfo values('Sathish','Gujarat','BTM','9948497734','EPAN121','pass@121','satish@gmail.com')
insert tbl_CustomerInfo values('Sree','Mumbai','MG Road','9948493334','EPAN122','pass@122','sree@gmail.com')
insert tbl_CustomerInfo values('Kumar','HYD','BTM','9948490034','EPAN120','pass@120','kumar@gmail.com')

Select * from tbl_CustomerInfo


--AccountInfo with auto gen AccountID
--(AccountID(PK),CustomerID(FK),AccountType,AccountBalance,AccountOpenDate, 
--AccountStatus(Open,Closed,Blocked)) 

Create Table tbl_AccountInfo
(
AccountID int identity(100000,1) primary key,
CustomerID int foreign key references tbl_CustomerInfo(CustomerID),
AccountType varchar(100) not null,
AccountBalance int not null,
AccountOpenDate datetime not null,
AccountStatus varchar(100) not null
)

--Insert Records

insert tbl_AccountInfo values(1000,'Savings',50000,getdate(),'Open')
insert tbl_AccountInfo values(1000,'Current',150000,getdate(),'Closed')
insert tbl_AccountInfo values(1001,'Savings',250000,getdate(),'Open')
insert tbl_AccountInfo values(1002,'Current',350000,getdate(),'Blocked')
insert tbl_AccountInfo values(1003,'Savings',450000,getdate(),'Closed')
insert tbl_AccountInfo values(1004,'Current',550000,getdate(),'Closed')
insert tbl_AccountInfo values(1003,'Savings',650000,getdate(),'Blocked')
insert tbl_AccountInfo values(1002,'Current',750000,getdate(),'Blocked')
insert tbl_AccountInfo values(1005,'Savings',850000,getdate(),'Open')
insert tbl_AccountInfo values(1006,'Current',950000,getdate(),'Closed')

Select * from tbl_AccountInfo


--TransactionInfo with Auto gen TransactionID
--(TransactionID (PK),AccountID (FK),TransactionType (D,C),Amount (>0),TransactionDate)

Create Table tbl_TransactionInfo
(
TransactionID int identity(1,1) primary key,
AccountID int foreign key references tbl_AccountInfo(AccountID),
TransactionType varchar(100) not null,
Amount int not null check (Amount>0),
TransactionDate datetime not null
)

--Insert Records

insert tbl_TransactionInfo values(100000,'Credit',20000,'12/13/2018')
insert tbl_TransactionInfo values(100000,'Debit',30000,'12/15/2018')
insert tbl_TransactionInfo values(100001,'Credit',25000,'12/15/2018')
insert tbl_TransactionInfo values(100002,'Debit',35000,'12/16/2018')
insert tbl_TransactionInfo values(100003,'Credit',40000,'12/16/2018')
insert tbl_TransactionInfo values(100001,'Debit',25000,'12/18/2018')
insert tbl_TransactionInfo values(100002,'Credit',50000,'12/18/2018')
insert tbl_TransactionInfo values(100005,'Debit',35000,'12/21/2018')
insert tbl_TransactionInfo values(100006,'Credit',45000,'12/21/2018')
insert tbl_TransactionInfo values(100004,'Debit',20000,'12/21/2018')

Select * from tbl_TransactionInfo

--Reports

--Latest 5 transactions of an account (Enter Account ID as an Input)

Select top 5 * from tbl_TransactionInfo order by TransactionDate desc
  
--Transaction between two dates of an account (Enter Account ID as an Input)

Select * from tbl_TransactionInfo where TransactionDate between getdate() and '12/16/2018' 
and AccountID=100000

--List of Accounts of a Customer (Enter Customer ID as an input)

Select * from tbl_AccountInfo where CustomerID=1000

--List of customers(CustomerID,CustomerName,CustomerAddress,CustomerMobileNo, AccountID , AccountBalance)

Select tbl_CustomerInfo.CustomerID,tbl_CustomerInfo.CustomerName,tbl_CustomerInfo.CustomerAddress,
tbl_CustomerInfo.CustomerMobileNo,tbl_AccountInfo.AccountID,tbl_AccountInfo.AccountBalance
from tbl_CustomerInfo
join tbl_AccountInfo
on
tbl_CustomerInfo.CustomerID=tbl_AccountInfo.CustomerID

--List of accounts with transactions (AccountID , AccountBalance , TransID , Amount, TransationType)

Select tbl_AccountInfo.AccountID,tbl_AccountInfo.AccountBalance,tbl_TransactionInfo.TransactionID,
tbl_TransactionInfo.Amount,tbl_TransactionInfo.TransactionType 
from tbl_AccountInfo join tbl_TransactionInfo
on
tbl_AccountInfo.AccountID=tbl_TransactionInfo.AccountID 

--List of customers with accounts and transations (CustomerID,CustomerName,CustomerAddress,CustomerMobileNo, 
--AccountID , AccountBalance,TransationID , Amount, TransationType)

Select tbl_CustomerInfo.CustomerID,tbl_CustomerInfo.CustomerName,tbl_CustomerInfo.CustomerAddress,
tbl_CustomerInfo.CustomerMobileNo,tbl_AccountInfo.AccountID,tbl_AccountInfo.AccountBalance,
tbl_TransactionInfo.TransactionID,tbl_TransactionInfo.Amount,tbl_TransactionInfo.TransactionType
from tbl_CustomerInfo
join tbl_AccountInfo
on
tbl_CustomerInfo.CustomerID=tbl_AccountInfo.CustomerID
join tbl_TransactionInfo
on
tbl_AccountInfo.AccountID=tbl_TransactionInfo.AccountID

--List of Customers who have accounts

Select * from tbl_CustomerInfo where CustomerID in(Select distinct CustomerID from tbl_AccountInfo)

--List of Customer who have no account

Select * from tbl_CustomerInfo where CustomerID not in(Select distinct CustomerID from tbl_AccountInfo)

--List of Account which has transaction

Select * from tbl_AccountInfo where AccountID in(Select distinct AccountID from tbl_TransactionInfo)

--List of Account which has no transaction

Select * from tbl_AccountInfo where AccountID not in(Select distinct AccountID from tbl_TransactionInfo)


























